package uo.sdi.dto.types;

public enum UserStatusDTO {

	ENABLED, DISABLED
	
}
