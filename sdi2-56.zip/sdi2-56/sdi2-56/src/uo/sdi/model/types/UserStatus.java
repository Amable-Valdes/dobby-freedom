package uo.sdi.model.types;

public enum UserStatus {
	ENABLED,
	DISABLED
}
